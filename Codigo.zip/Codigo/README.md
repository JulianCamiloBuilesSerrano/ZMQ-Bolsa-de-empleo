#Ejecución del codigo 
para la ejecución del servidor 
py.exe servidor.py
para la ejecucuón del filtro
py.exe filtro.py
para la ejecución del empleador
py.exe Empleador.py